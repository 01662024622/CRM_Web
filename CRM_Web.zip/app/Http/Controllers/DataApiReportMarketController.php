<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DataApiReportMarketController extends Controller
{
    //
}
