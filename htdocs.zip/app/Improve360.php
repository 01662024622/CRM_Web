<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Improve360 extends Model
{
    protected $fillable = [
        'content'
    ];
    protected $table = "improve_360";
}
