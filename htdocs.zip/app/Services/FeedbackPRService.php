<?php


namespace App\Services;


interface FeedbackPRService extends Service
{

}
