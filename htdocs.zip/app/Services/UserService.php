<?php
namespace App\Services;

interface UserService extends Service{

}

