<?php
namespace App\Services;

interface ReportMarketService extends Service{

}

