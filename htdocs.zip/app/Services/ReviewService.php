<?php


namespace App\Services;


interface ReviewService extends Service{

}

