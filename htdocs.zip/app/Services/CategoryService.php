<?php


namespace App\Services;


interface CategoryService extends Service
{

}
