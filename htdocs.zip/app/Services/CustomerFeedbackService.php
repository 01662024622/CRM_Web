<?php


namespace App\Services;


interface CustomerFeedbackService extends Service
{

}
