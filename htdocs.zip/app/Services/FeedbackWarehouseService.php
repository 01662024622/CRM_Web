<?php


namespace App\Services;


interface FeedbackWarehouseService extends Service
{

}
