<?php
namespace App\Services;

interface FeedbackService extends Service
{

}
