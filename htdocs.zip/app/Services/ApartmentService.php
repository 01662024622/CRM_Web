<?php
namespace App\Services;


interface ApartmentService extends Service{

}

