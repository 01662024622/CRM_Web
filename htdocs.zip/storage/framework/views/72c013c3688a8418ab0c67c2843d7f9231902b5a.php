<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/review360/main.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <br><br>
    <table class="table table-bordered" id="users-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Loại</th>
            <th>Mã</th>
            <th>Số Lượng</th>
            <th>Nội dung</th>
            <th>Ngày Tạo</th>
        </tr>
        </thead>
    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/review360/feedbackWarehouseManager.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/report_review/warehouseManager.blade.php ENDPATH**/ ?>