<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/review360/feedbackmeCustomerRender.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<form action="/action_page.php">
		<label for="email">Mã Khách hàng(*)</label>
		<div class="row">
			<div class="col-10">
				<div class="form-group">
					<input type="text" class="form-control" name="code" placeholder="Hãy nhập mã khách hàng" id="code">
				</div>
			</div>
			<div class="col-2">
				<button type="submit" class="btn btn-primary">Nhận Link</button>
			</div>
		</div>
	</form>
<div class="row" id="link-container">
	<div class="col-10">
		<input type="text" class="form-control" placeholder="Hãy nhập mã khách hàng" id="link">
	</div>
	<div class="col-2">
		<button type="submit" id="coppy" class="btn btn-primary">Coppy Link</button>
	</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/review360/feedbackmeCustomerRender.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/report_review/feedbackCustomerRender.blade.php ENDPATH**/ ?>