
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<br><br>
<button type="button" class="btn btn-primary" onclick="clearForm()" data-toggle="modal" href='#add-modal'>+Thêm mới</button>

<br><br>
<table class="table table-bordered" id="users-table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Tên Phòng Ban</th>
      <th>Mã Phòng Ban</th>
      <th>Quản lý</th>
      <th>Chú Thích</th>
      <th>Hành Động</th>
    </tr>
  </thead>
</table>


<!-- The Modal -->
<div class="modal" id="add-modal">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Thêm mới</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <form id="add-form" action="<?php echo e(asset('/apartments')); ?>" method="POST" >
        <!-- Modal body -->
        <div class="modal-body">
          <div class="form-group">
            <label for="name">Tên Phòng Ban*</label>
            <input type="text" class="form-control" id="name" name="name"  placeholder="Nhập Tên Phòng Ban...">
          </div>
          <div class="form-group">
            <label for="name">Mã Phòng Ban*</label>
            <input type="text" class="form-control" id="code" name="code"  placeholder="Nhập Mã Phòng Ban...">
          </div>
          <div class="form-group">
            <label for="card-holder" class="form-label-header">Quản Lý</label>
            <select class="form-control" id="user_id" name="user_id">
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label for="name">Note</label>
            <input type="text" class="form-control" id="description" name="description"  placeholder="Chú thích...">
          </div>
          <input type="hidden" name="id" id="eid">

        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/apartment/index.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/apartments/index.blade.php ENDPATH**/ ?>