<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/review360/feedbackme.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<br><br>
<table class="table table-bordered" id="users-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nội dung</th>
            <th>Ghi chú</th>
            <th>Phản Hồi</th>
            <th>Hành động</th>
        </tr>
    </thead>
</table>


<!-- The Modal -->
<div class="modal" id="add-modal">
    <div class="modal-dialog" style="max-width: 700px;">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Phản hồi</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <form id="add-form" action="#" method="GET">
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Nội dung</label>
                        <textarea class="form-control" name="option" id="option" rows="3"></textarea>
                    </div>

                </div>

                <input type="hidden" name="id" id="eid">
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/review360/feedbackme.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/report_review/feedbackme.blade.php ENDPATH**/ ?>